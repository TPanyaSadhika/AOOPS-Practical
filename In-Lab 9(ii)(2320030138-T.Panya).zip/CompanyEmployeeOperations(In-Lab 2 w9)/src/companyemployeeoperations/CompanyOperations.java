package companyemployeeoperations;

import java.util.*;
import java.util.stream.Collectors;

public class CompanyOperations {
    public static void main(String[] args) {
        // Create a list of employees
        List<Employee> employees = Arrays.asList(
            new Employee("Alice", 30, "HR", 50000),
            new Employee("Bob", 35, "Finance", 75000),
            new Employee("Charlie", 25, "IT", 60000),
            new Employee("David", 40, "Finance", 85000),
            new Employee("Eve", 28, "IT", 45000)
        );

        // 1. Filter employees by department
        String departmentToFilter = "IT";
        List<Employee> itEmployees = employees.stream()
            .filter(emp -> emp.getDepartment().equals(departmentToFilter))
            .collect(Collectors.toList());

        System.out.println("Employees in IT department:");
        itEmployees.forEach(System.out::println);

        // 2. Sort employees by their names
        List<Employee> sortedByName = employees.stream()
            .sorted(Comparator.comparing(Employee::getName))
            .collect(Collectors.toList());

        System.out.println("\nEmployees sorted by name:");
        sortedByName.forEach(System.out::println);

        // 3. Find the employee with the highest salary
        Employee highestSalaryEmployee = employees.stream()
            .max(Comparator.comparingDouble(Employee::getSalary))
            .orElse(null);

        System.out.println("\nEmployee with the highest salary:");
        System.out.println(highestSalaryEmployee);

        // 4. Calculate the average salary of employees
        double averageSalary = employees.stream()
            .mapToDouble(Employee::getSalary)
            .average()
            .orElse(0.0);

        System.out.println("\nAverage salary of employees: " + averageSalary);
    }
}

