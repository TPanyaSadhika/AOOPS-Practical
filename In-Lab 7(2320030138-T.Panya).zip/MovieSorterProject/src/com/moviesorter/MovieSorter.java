package com.moviesorter;

import java.util.ArrayList;
import java.util.Collections;

public class MovieSorter {
    public static void main(String[] args) {
        ArrayList<Movie> movies = new ArrayList<>();
        movies.add(new Movie("The Godfather", 9.2, 1972));
        movies.add(new Movie("The Dark Knight", 9.0, 2008));
        movies.add(new Movie("Pulp Fiction", 8.9, 1994));
        movies.add(new Movie("Forrest Gump", 8.8, 1994));

        // Sorting the list of movies based on the year
        Collections.sort(movies);

        // Displaying the sorted list
        for (Movie movie : movies) {
            System.out.println(movie);
        }
    }
}


