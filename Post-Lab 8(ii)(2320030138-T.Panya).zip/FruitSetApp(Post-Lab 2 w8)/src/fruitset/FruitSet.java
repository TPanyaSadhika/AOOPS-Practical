package fruitset;

import java.util.Set;
import java.util.TreeSet;

public class FruitSet {

    public static void main(String[] args) {
        // Create a TreeSet to store fruits in alphabetical order
        Set<String> fruitSet = new TreeSet<>();

        // Add some fruits to the set
        fruitSet.add("Apple");
        fruitSet.add("Banana");
        fruitSet.add("Orange");
        fruitSet.add("Mango");
        fruitSet.add("Grapes");

        // Iterate over the set and print each fruit in alphabetical order
        System.out.println("Fruits in alphabetical order:");
        for (String fruit : fruitSet) {
            System.out.println(fruit);
        }
    }
}
