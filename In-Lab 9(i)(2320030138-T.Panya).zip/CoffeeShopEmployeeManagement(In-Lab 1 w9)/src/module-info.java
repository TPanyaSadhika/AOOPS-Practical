/**
 * 
 */
/**
 * 
 */
module CoffeeShopEmployeeManagement {
}