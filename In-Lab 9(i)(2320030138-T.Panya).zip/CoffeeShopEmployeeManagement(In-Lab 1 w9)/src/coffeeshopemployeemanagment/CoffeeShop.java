package coffeeshopemployeemanagment;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.Comparator;

public class CoffeeShop {
    public static void main(String[] args) {
        // Create employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Employee1", 30, 5));
        employees.add(new Employee("Employee2", 28, 4));
        employees.add(new Employee("Employee3", 25, 3));
        employees.add(new Employee("Employee4", 22, 1));
        employees.add(new Employee("Employee5", 20, 0));

        // Sort employees by experience in descending order
        employees.sort(Comparator.comparingInt(Employee::getExperience).reversed());

        System.out.println("Employees sorted by experience:");
        for (Employee emp : employees) {
            System.out.println(emp);
        }

        // Predicate to filter employees with experience > 2 years
        Predicate<Employee> hasMoreThanTwoYearsExperience = emp -> emp.getExperience() > 2;

        System.out.println("\nEmployees eligible for bonus (experience > 2 years):");
        for (Employee emp : employees) {
            if (hasMoreThanTwoYearsExperience.test(emp)) {
                System.out.println(emp.getName() + " is eligible for a bonus.");
            } else {
                System.out.println(emp.getName() + " is not eligible for a bonus.");
            }
        }
    }
}

