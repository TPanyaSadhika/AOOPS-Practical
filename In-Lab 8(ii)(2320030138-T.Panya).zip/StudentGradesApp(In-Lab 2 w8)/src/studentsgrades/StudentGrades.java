package studentsgrades;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class StudentGrades {
    // Map to store student grades (Student ID as key, Set of grades as value)
    private Map<String, Set<Integer>> studentGrades;

    // Constructor to initialize the studentGrades map
    public StudentGrades() {
        studentGrades = new HashMap<>();
    }

    // Method to add a grade for a student based on their ID
    public void addGrade(String studentId, int grade) {
        // Get the set of grades for the student, or create a new set if not present
        Set<Integer> grades = studentGrades.getOrDefault(studentId, new HashSet<>());
        grades.add(grade);
        studentGrades.put(studentId, grades);
        System.out.println("Added grade " + grade + " for student ID: " + studentId);
    }

    // Method to retrieve the grades of a student by their ID
    public Set<Integer> getGrades(String studentId) {
        return studentGrades.getOrDefault(studentId, new HashSet<>());
    }

    // Main method to demonstrate the functionality of the StudentGrades class
    public static void main(String[] args) {
        StudentGrades sg = new StudentGrades();

        // Adding grades for students
        sg.addGrade("S123", 85);
        sg.addGrade("S123", 90);
        sg.addGrade("S124", 78);
        sg.addGrade("S125", 92);

        // Retrieving and displaying grades for a student by their ID
        System.out.println("Grades for student S123: " + sg.getGrades("S123"));
        System.out.println("Grades for student S124: " + sg.getGrades("S124"));
        System.out.println("Grades for student S125: " + sg.getGrades("S125"));
    }
}
