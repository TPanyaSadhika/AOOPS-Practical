package com.messaging;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class Producer implements Runnable {
    private final BlockingQueue<String> sharedQueue;

    public Producer(BlockingQueue<String> sharedQueue) {
        this.sharedQueue = sharedQueue;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) {
                String message = "Message " + i;
                System.out.println(Thread.currentThread().getName() + " produced: " + message);
                sharedQueue.put(message); // Put message into the shared buffer
                TimeUnit.SECONDS.sleep(1); // Simulate time delay in message production
            }
            sharedQueue.put("DONE"); // Indicate end of production
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

