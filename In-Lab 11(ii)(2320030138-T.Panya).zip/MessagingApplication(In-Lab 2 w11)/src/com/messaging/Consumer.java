package com.messaging;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable {
    private final BlockingQueue<String> sharedQueue;

    public Consumer(BlockingQueue<String> sharedQueue) {
        this.sharedQueue = sharedQueue;
    }

    @Override
    public void run() {
        try {
            String message;
            while (!(message = sharedQueue.take()).equals("DONE")) {
                System.out.println(Thread.currentThread().getName() + " consumed: " + message);
            }
            System.out.println(Thread.currentThread().getName() + " finished consuming.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

