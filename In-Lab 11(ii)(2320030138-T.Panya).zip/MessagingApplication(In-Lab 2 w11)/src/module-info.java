/**
 * 
 */
/**
 * 
 */
module MessagingApplication {
}