package bubble;

import java.util.Arrays;

public class BubbleSortTest {

    public static void main(String[] args) {
        Integer[] intArray = {5, 1, 4, 2, 8};
        System.out.println("Before sorting (Integers): " + Arrays.toString(intArray));
        BubbleSort.bubbleSort(intArray);
        System.out.println("After sorting (Integers): " + Arrays.toString(intArray));

        Double[] doubleArray = {64.5, 34.3, 25.5, 12.1, 22.4};
        System.out.println("Before sorting (Doubles): " + Arrays.toString(doubleArray));
        BubbleSort.bubbleSort(doubleArray);
        System.out.println("After sorting (Doubles): " + Arrays.toString(doubleArray));

        String[] stringArray = {"pear", "apple", "orange", "banana"};
        System.out.println("Before sorting (Strings): " + Arrays.toString(stringArray));
        BubbleSort.bubbleSort(stringArray);
        System.out.println("After sorting (Strings): " + Arrays.toString(stringArray));
    }
}
