/**
 * 
 */
/**
 * 
 */
module GenericsWithInterfacesExample {
}