package com.example.generics;
interface MinMax<T extends Comparable<T>> {
    T findMin(T[] array);
    T findMax(T[] array);
}
class ArrayOperations<T extends Comparable<T>> implements MinMax<T> {

    @Override
    public T findMin(T[] array) {
        T min = array[0];
        for (T element : array) {
            if (element.compareTo(min) < 0) {
                min = element;
            }
        }
        return min;
    }

    @Override
    public T findMax(T[] array) {
        T max = array[0];
        for (T element : array) {
            if (element.compareTo(max) > 0) {
                max = element;
            }
        }
        return max;
    }
}

// Step 3: Test the implementation with different data types
public class GenericsWithInterfaces {
    public static void main(String[] args) {
        // Integer array
        Integer[] intArray = {5, 3, 8, 1, 9, 4};
        ArrayOperations<Integer> intOps = new ArrayOperations<>();
        System.out.println("Integer Array: ");
        System.out.println("Minimum: " + intOps.findMin(intArray));
        System.out.println("Maximum: " + intOps.findMax(intArray));
        
        // String array
        String[] strArray = {"apple", "orange", "banana", "grape"};
        ArrayOperations<String> strOps = new ArrayOperations<>();
        System.out.println("\nString Array: ");
        System.out.println("Minimum: " + strOps.findMin(strArray));
        System.out.println("Maximum: " + strOps.findMax(strArray));
        
        // Character array
        Character[] charArray = {'A', 'X', 'B', 'Z', 'C'};
        ArrayOperations<Character> charOps = new ArrayOperations<>();
        System.out.println("\nCharacter Array: ");
        System.out.println("Minimum: " + charOps.findMin(charArray));
        System.out.println("Maximum: " + charOps.findMax(charArray));
        
        // Float array
        Float[] floatArray = {3.6f, 1.2f, 7.4f, 5.5f, 2.1f};
        ArrayOperations<Float> floatOps = new ArrayOperations<>();
        System.out.println("\nFloat Array: ");
        System.out.println("Minimum: " + floatOps.findMin(floatArray));
        System.out.println("Maximum: " + floatOps.findMax(floatArray));
    }
}
