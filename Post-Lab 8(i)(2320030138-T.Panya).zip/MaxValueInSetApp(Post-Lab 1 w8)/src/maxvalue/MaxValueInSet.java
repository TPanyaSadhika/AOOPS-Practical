package maxvalue;

import java.util.HashSet;
import java.util.Set;

public class MaxValueInSet {

    // Method to find the maximum value in a set of integers
    public static int findMax(Set<Integer> numbers) {
        // Initialize max value to the minimum possible integer
        int max = Integer.MIN_VALUE;
        
        // Iterate through the set to find the maximum value
        for (int num : numbers) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }

    // Main method to demonstrate finding the maximum value in a set
    public static void main(String[] args) {
        // Create a set of integers
        Set<Integer> numbers = new HashSet<>();
        numbers.add(45);
        numbers.add(22);
        numbers.add(78);
        numbers.add(33);
        numbers.add(56);

        // Find and display the maximum value
        int maxValue = findMax(numbers);
        System.out.println("The maximum value in the set is: " + maxValue);
    }
}
