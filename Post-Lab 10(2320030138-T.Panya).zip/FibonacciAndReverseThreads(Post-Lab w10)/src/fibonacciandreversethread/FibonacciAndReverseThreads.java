package fibonacciandreversethread;

public class FibonacciAndReverseThreads {

    public static void main(String[] args) {
        // Create a thread for Fibonacci series
        Runnable fibonacciTask = new Runnable() {
            @Override
            public void run() {
                int num1 = 0, num2 = 1;
                System.out.println("Fibonacci Series:");
                for (int i = 1; i <= 10; i++) {
                    System.out.print(num1 + " ");
                    int nextTerm = num1 + num2;
                    num1 = num2;
                    num2 = nextTerm;
                }
                System.out.println(); // Move to next line after the Fibonacci series
            }
        };

        // Create a thread for reverse order from 10 to 1
        Runnable reverseTask = new Runnable() {
            @Override
            public void run() {
                System.out.println("Reverse Order:");
                for (int i = 10; i >= 1; i--) {
                    System.out.print(i + " ");
                }
                System.out.println(); // Move to next line after the reverse order
            }
        };

        // Create and start the threads
        Thread fibonacciThread = new Thread(fibonacciTask);
        Thread reverseThread = new Thread(reverseTask);

        fibonacciThread.start(); // Start Fibonacci thread
        reverseThread.start();   // Start reverse order thread

        try {
            // Wait for both threads to finish
            fibonacciThread.join();
            reverseThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Both threads have finished execution.");
    }
}

