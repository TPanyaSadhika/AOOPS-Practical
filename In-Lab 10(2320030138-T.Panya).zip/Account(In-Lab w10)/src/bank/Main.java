package bank;



public class Main {
    public static void main(String[] args) {
        Account account = new Account(12345, 1000);

        // Create threads using TransactionRunnable
        TransactionRunnable depositRunnable = new TransactionRunnable(account, 200, true);
        TransactionRunnable withdrawRunnable = new TransactionRunnable(account, 150, false);
        
        Thread depositThread1 = new Thread(depositRunnable);
        Thread withdrawThread1 = new Thread(withdrawRunnable);

        // Create threads using TransactionThread
        TransactionThread depositThread2 = new TransactionThread(account, 300, true);
        TransactionThread withdrawThread2 = new TransactionThread(account, 400, false);

        // Start all threads
        depositThread1.start();
        withdrawThread1.start();
        depositThread2.start();
        withdrawThread2.start();

        try {
            // Wait for threads to finish
            depositThread1.join();
            withdrawThread1.join();
            depositThread2.join();
            withdrawThread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Print final balance
        System.out.println("Final balance: " + account.getBalance());
    }
}

