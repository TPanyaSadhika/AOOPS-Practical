package boundedbuffer;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class Producer implements Runnable {
    private final BlockingQueue<Integer> buffer;
    private final int maxItems;

    public Producer(BlockingQueue<Integer> buffer, int maxItems) {
        this.buffer = buffer;
        this.maxItems = maxItems;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= maxItems; i++) {
                System.out.println("Producer is producing: " + i);
                buffer.put(i); // Put item into the buffer
                TimeUnit.SECONDS.sleep(1); // Simulate production time
            }
            buffer.put(-1); // End signal for consumer
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

