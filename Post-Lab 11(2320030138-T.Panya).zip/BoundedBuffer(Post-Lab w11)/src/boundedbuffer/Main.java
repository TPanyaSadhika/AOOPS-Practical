package boundedbuffer;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {
    public static void main(String[] args) {
        // Create a bounded buffer with a maximum capacity of 10 items
        BlockingQueue<Integer> buffer = new ArrayBlockingQueue<>(10);

        // Create producer and consumer threads
        Thread producerThread = new Thread(new Producer(buffer, 10));
        Thread consumerThread = new Thread(new Consumer(buffer));

        // Start producer and consumer threads
        producerThread.start();
        consumerThread.start();

        // Wait for threads to complete execution
        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Bounded buffer simulation finished.");
    }
}

