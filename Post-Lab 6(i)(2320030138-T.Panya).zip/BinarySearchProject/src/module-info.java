/**
 * 
 */
/**
 * 
 */
module BinarySearchProject {
}