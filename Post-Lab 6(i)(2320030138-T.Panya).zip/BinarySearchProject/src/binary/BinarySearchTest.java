package binary;

public class BinarySearchTest {
    public static void main(String[] args) {
       
        BinarySearch<Integer> intSearch = new BinarySearch<>();
        Integer[] intArray = {1, 3, 5, 7, 9, 11, 13};
        int intResult = intSearch.binarySearch(intArray, 7);
        System.out.println("Integer 7 found at index: " + intResult);

        BinarySearch<Double> doubleSearch = new BinarySearch<>();
        Double[] doubleArray = {1.1, 2.2, 3.3, 4.4, 5.5};
        int doubleResult = doubleSearch.binarySearch(doubleArray, 4.4);
        System.out.println("Double 4.4 found at index: " + doubleResult);

        BinarySearch<String> stringSearch = new BinarySearch<>();
        String[] stringArray = {"apple", "banana", "cherry", "date", "fig"};
        int stringResult = stringSearch.binarySearch(stringArray, "cherry");
        System.out.println("String 'cherry' found at index: " + stringResult);
    }
}
