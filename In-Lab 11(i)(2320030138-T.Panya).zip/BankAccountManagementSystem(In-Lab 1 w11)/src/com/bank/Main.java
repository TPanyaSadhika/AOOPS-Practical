package com.bank;

public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000); // Initial balance of 1000

        // Creating deposit and withdrawal tasks
        Thread user1 = new Thread(new TransactionTask(account, true, 500), "User 1");
        Thread user2 = new Thread(new TransactionTask(account, false, 300), "User 2");
        Thread user3 = new Thread(new TransactionTask(account, true, 200), "User 3");
        Thread user4 = new Thread(new TransactionTask(account, false, 1000), "User 4");

        // Starting the threads
        user1.start();
        user2.start();
        user3.start();
        user4.start();

        // Wait for all threads to finish
        try {
            user1.join();
            user2.join();
            user3.join();
            user4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display final balance
        System.out.println("Final Balance: " + account.getBalance());
    }
}

