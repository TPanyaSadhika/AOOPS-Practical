package com.employeesorter;

import java.util.Comparator;

public class EmployeeComparators {

    // Comparator to sort by salary (ascending)
    public static Comparator<Employee> compareBySalaryAsc = (e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary());

    // Comparator to sort by salary (descending)
    public static Comparator<Employee> compareBySalaryDesc = (e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary());

    // Comparator to sort by name (alphabetical)
    public static Comparator<Employee> compareByName = (e1, e2) -> e1.getName().compareTo(e2.getName());

    // Comparator to sort by department (alphabetical)
    public static Comparator<Employee> compareByDepartment = (e1, e2) -> e1.getDepartment().compareTo(e2.getDepartment());
}

