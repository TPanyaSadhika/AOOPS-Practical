package com.employeesorter;

import java.util.ArrayList;
import java.util.Collections;

public class EmployeeSorter {
    public static void main(String[] args) {
        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "John Doe", "Marketing", 55000));
        employees.add(new Employee(2, "Jane Smith", "HR", 62000));
        employees.add(new Employee(3, "Alice Johnson", "IT", 72000));
        employees.add(new Employee(4, "Bob Brown", "Marketing", 48000));

        System.out.println("Employees sorted by salary (ascending):");
        Collections.sort(employees, EmployeeComparators.compareBySalaryAsc);
        employees.forEach(System.out::println);

        System.out.println("\nEmployees sorted by salary (descending):");
        Collections.sort(employees, EmployeeComparators.compareBySalaryDesc);
        employees.forEach(System.out::println);

        System.out.println("\nEmployees sorted by name (alphabetical):");
        Collections.sort(employees, EmployeeComparators.compareByName);
        employees.forEach(System.out::println);

        System.out.println("\nEmployees sorted by department (alphabetical):");
        Collections.sort(employees, EmployeeComparators.compareByDepartment);
        employees.forEach(System.out::println);
    }
}

