package cade;

import java.util.List;

public class CadetSorting {

    // Method to check if cadets are sorted alphabetically
    public static boolean isSorted(List<String> cadetNames) {
        for (int i = 1; i < cadetNames.size(); i++) {
            if (cadetNames.get(i - 1).compareTo(cadetNames.get(i)) > 0) {
                return false;
            }
        }
        return true;
    }
}
