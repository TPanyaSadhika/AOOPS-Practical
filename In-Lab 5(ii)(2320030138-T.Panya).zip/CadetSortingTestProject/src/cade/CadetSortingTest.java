package cade;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;

public class CadetSortingTest {

    // Test for an empty list
    @Test
    public void testEmptyList() {
        assertTrue(CadetSorting.isSorted(Collections.emptyList()), "An empty list should be considered sorted.");
    }

    // Test for a single cadet
    @Test
    public void testSingleCadet() {
        assertTrue(CadetSorting.isSorted(Collections.singletonList("Arjun")), "A list with one cadet should be considered sorted.");
    }

    // Test for multiple cadets sorted alphabetically
    @Test
    public void testMultipleCadetsSorted() {
        assertTrue(CadetSorting.isSorted(Arrays.asList("Arjun", "Bhaskar", "Chitra", "Divya")),
                "The list of cadets is already sorted.");
    }

    // Test for multiple cadets not sorted
    @Test
    public void testMultipleCadetsNotSorted() {
        assertFalse(CadetSorting.isSorted(Arrays.asList("Divya", "Arjun", "Bhaskar", "Chitra")),
                "The list of cadets is not sorted.");
    }

    // Test for cadets with identical names
    @Test
    public void testCadetsWithIdenticalNames() {
        assertTrue(CadetSorting.isSorted(Arrays.asList("Arjun", "Arjun", "Bhaskar", "Chitra")),
                "A list with identical names should be considered sorted if in the correct order.");
    }
}

